# importing Libraries
from flask import Flask, jsonify, request

# creating a flask instance
app = Flask(__name__)

# creating a dummy DB
products_db = [{
    'SKU' : 'north ameria',
    'Name' : 'apple',
    'Description' : 'last month premium product',
    'Category'  : " A1 class",
    'Price'     : 410,
    'MetaData'  : 'Small Icon'

},
    {
                      'SKU': 'center ameria',
                      'Name': 'apple',
                      'Description': 'last month premium product',
                      'Category': " A1 class",
                      'Price': 254,
                      'MetaData': 'large Icon'}
              ]


# retrieve all the products   http://127.0.0.1:1224/products
@app.route('/products',)
def get_all_product():
    return jsonify({'products':products_db})


# retrieve one product  http://127.0.0.1:1224/product/Name
@app.route('/product/<string:name>')
def get_product(name):
    for product in products_db:
        if product['Name'] == name:
            return jsonify(product)

    return jsonify({'message': 'no product found'})


# create a product  http://127.0.0.1:1224/product/
@app.route('/product', methods=['POST'])
def create_product():
    product_data = request.get_json()
    products_db.append(product_data)
    return jsonify({"message": "product created successfully"})

# update a product  http://127.0.0.1:1224/update/name
@app.route('/update/<string:name>', methods=['PUT'])
def update_product(name):
    for product in products_db:
        if product['Name'] == name:
            post_data = request.json
            products_db.insert(0,{'SKU': post_data['SKU'],
                                  'Name':post_data['Name'],
                                  'Description': post_data['Description'],
                                  'Category': post_data['Category'],
                                  'Price':post_data['Price'],
                                  'MetaData':post_data ['MetaData']
                                  })
            return "Update successfully"
        else:
            return"produt name is not found"

# update a product  http://127.0.0.1:1224/delete/name
@app.route('/delete/<string:name>', methods=['DELETE'])
def delete_product(name):
    for product in products_db:
        if product['Name'] == name:
            products_db.remove(product)
            return "Delete Successfully"
        else:
            return"produt name is not found"

app.run(debug=True,port=1224)